#Make a list. In the list put each webpage into a dictionary.

pages = [
	{

		"filename": "content/about.html",
		"output": "docs/about.html",
		"title": "About Me",
	},
	{
		"filename": "content/articles.html",
		"output": "docs/articles.html",
		"title": "Travel articles",
	},
	{
		"filename": "content/gallery.html",
		"output": "docs/gallery.html",
		"title": "Travel Gallery",
	},
	{
		"filename": "content/index.html",
		"output": "docs/index.html",
		"title": "Home",
	},

	]

#Writing main function to combine files

# def main():

# 	top_part=open('Templates/top.html').read()
# 	bottom_part=open('Templates/bottom.html').read()
# 	middle_about=open('Docs/aboutmiddle.html').read()
# 	middle_index=open('Docs/indexmiddle.html').read()
# 	middle_gallery=open('Docs/gallerymiddle.html').read()
# 	middle_articles=open('Docs/articlesmiddle.html').read()


# 	main_gallery = top_part + middle_gallery + bottom_part
# 	main_about= top_part + middle_about + bottom_part
# 	main_index=top_part + middle_index + bottom_part
# 	main_articles=top_part + middle_articles + bottom_part

# 	open('gallery.html','w+').write(main_gallery)
# 	open('about.html','w+').write(main_about)
# 	open('index.html','w+').write(main_index)
# 	open('articles.html','w+').write(main_articles)

# #invoking the function below

# if __name__ == '__main__':
# 	main()


# def dictread():
# # Accessing the data in each of the dictionaries
# 	for eachpage in pages:
# 		page_title = eachpage["title"]
# 		print(page_title)



# def apply_template(eachpage, base, content):
    
#     page = base.replace('{{content}}', content)
#     page = page.replace('{{title}}', eachpage['title'])
# 	return page


# def strreplace():

# 	base = open('Templates/base.html').read()
# 	content = open(eachpage['output']).read()
# 	resulting_html_page = apply_template(eachpage, base, content)
# 	open(page['output'], 'w+').write(resulting_html_page)


